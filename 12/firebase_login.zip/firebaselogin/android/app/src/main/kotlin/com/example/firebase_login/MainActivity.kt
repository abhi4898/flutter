package com.example.firebase_login

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
